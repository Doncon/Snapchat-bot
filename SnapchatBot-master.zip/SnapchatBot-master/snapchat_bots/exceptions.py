class UnknownMediaType(Exception):
    pass

class CannotOpenFile(Exception):
    pass
